ARTICLE_ID = 16519 # Bertin Emilienne on Maitron, full access with no user account
MAITRON_BASE_URL = "https://maitron.fr/spip.php?article"