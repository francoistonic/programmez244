fn main() {}

trait Animal {}
