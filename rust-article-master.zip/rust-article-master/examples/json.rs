use serde_json::json;

fn main() {
  let _value = json!({
      "code": 200,
      "success": true,
      "payload": {
          "features": [
              "serde",
              "json"
          ]
      }
  });
}
